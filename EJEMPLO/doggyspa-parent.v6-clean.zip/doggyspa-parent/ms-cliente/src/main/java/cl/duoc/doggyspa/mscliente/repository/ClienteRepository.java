package cl.duoc.doggyspa.mscliente.repository;

import cl.duoc.doggyspa.mscliente.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    Optional<Cliente> findByCorreo(String correo);

    boolean existsByCorreo(String correo);
}