package cl.duoc.doggyspa.frontendweb.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ServicioDTO {

    private Long idServicio;
    private String nombre;
    private String descripcion;
    private BigDecimal precio;
    private Integer duracionMinutos;
    private Boolean activo;
}