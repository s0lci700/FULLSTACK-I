package cl.duoc.doggyspa.mscliente.exception;

public class CorreoDuplicadoException extends RuntimeException {

    public CorreoDuplicadoException(String correo) {
        super("Ya existe un cliente registrado con el correo: " + correo);
    }
}