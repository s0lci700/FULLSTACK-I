package cl.duoc.doggyspa.frontendweb.controller;

import cl.duoc.doggyspa.frontendweb.service.DoggySpaApiService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class WebController {

    private final DoggySpaApiService doggySpaApiService;

    @GetMapping({"/", "/inicio"})
    public String inicio(Model model) {
        model.addAttribute("titulo", "DoggySpa");
        return "inicio";
    }

    @GetMapping("/clientes")
    public String clientes(Model model) {
        model.addAttribute("titulo", "Clientes");
        model.addAttribute("clientes", doggySpaApiService.listarClientes());
        return "clientes";
    }

    @GetMapping("/mascotas")
    public String mascotas(Model model) {
        model.addAttribute("titulo", "Mascotas");
        model.addAttribute("mascotas", doggySpaApiService.listarMascotas());
        return "mascotas";
    }

    @GetMapping("/servicios")
    public String servicios(Model model) {
        model.addAttribute("titulo", "Servicios");
        model.addAttribute("servicios", doggySpaApiService.listarServicios());
        return "servicios";
    }

    @GetMapping("/reservas")
    public String reservas(Model model) {
        model.addAttribute("titulo", "Reservas");
        model.addAttribute("reservas", doggySpaApiService.listarReservas());
        return "reservas";
    }

    @GetMapping("/pagos")
    public String pagos(Model model) {
        model.addAttribute("titulo", "Pagos");
        model.addAttribute("pagos", doggySpaApiService.listarPagos());
        return "pagos";
    }
}