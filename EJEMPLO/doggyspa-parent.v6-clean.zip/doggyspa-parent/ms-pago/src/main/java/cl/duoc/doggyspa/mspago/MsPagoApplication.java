package cl.duoc.doggyspa.mspago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class MsPagoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsPagoApplication.class, args);
    }

}