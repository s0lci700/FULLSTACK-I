package cl.duoc.doggyspa.msreserva.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MascotaDTO {

    private Long idMascota;
    private String nombre;
    private String raza;
    private Integer edad;
    private BigDecimal peso;
    private String observacion;
    private Long idCliente;
}