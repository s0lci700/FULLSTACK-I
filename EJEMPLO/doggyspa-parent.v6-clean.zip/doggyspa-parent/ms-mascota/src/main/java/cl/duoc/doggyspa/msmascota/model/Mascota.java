package cl.duoc.doggyspa.msmascota.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "mascota")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Mascota {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_mascota")
    private Long idMascota;

    @NotBlank(message = "El nombre de la mascota es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    @Column(nullable = false, length = 100)
    private String nombre;

    @NotBlank(message = "La raza es obligatoria")
    @Size(max = 80, message = "La raza no puede superar los 80 caracteres")
    @Column(nullable = false, length = 80)
    private String raza;

    @NotNull(message = "La edad es obligatoria")
    @Min(value = 0, message = "La edad no puede ser negativa")
    @Max(value = 30, message = "La edad no puede superar los 30 años")
    @Column(nullable = false)
    private Integer edad;

    @NotNull(message = "El peso es obligatorio")
    @DecimalMin(value = "0.1", message = "El peso debe ser mayor a 0")
    @DecimalMax(value = "100.0", message = "El peso no puede superar los 100 kg")
    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal peso;

    @Size(max = 255, message = "La observación no puede superar los 255 caracteres")
    @Column(length = 255)
    private String observacion;

    @NotNull(message = "El ID del cliente es obligatorio")
    @Column(name = "id_cliente", nullable = false)
    private Long idCliente;
}