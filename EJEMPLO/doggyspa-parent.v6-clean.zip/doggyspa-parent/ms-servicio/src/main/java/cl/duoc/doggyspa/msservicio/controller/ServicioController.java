package cl.duoc.doggyspa.msservicio.controller;

import cl.duoc.doggyspa.msservicio.dto.ServicioRequestDTO;
import cl.duoc.doggyspa.msservicio.dto.ServicioResponseDTO;
import cl.duoc.doggyspa.msservicio.service.ServicioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/servicios")
@RequiredArgsConstructor
public class ServicioController {

    private final ServicioService servicioService;

    @GetMapping
    public ResponseEntity<?> listar() {
        log.info("Solicitud GET /api/v1/servicios");
        return ResponseEntity.ok(servicioService.listar());
    }

    @GetMapping("/activos")
    public ResponseEntity<?> listarActivos() {
        log.info("Solicitud GET /api/v1/servicios/activos");
        return ResponseEntity.ok(servicioService.listarActivos());
    }

    @GetMapping("/buscar")
    public ResponseEntity<?> buscarPorNombre(@RequestParam String nombre) {
        log.info("Solicitud GET /api/v1/servicios/buscar?nombre={}", nombre);
        return ResponseEntity.ok(servicioService.buscarPorNombre(nombre));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServicioResponseDTO> buscarPorId(@PathVariable Long id) {
        log.info("Solicitud GET /api/v1/servicios/{}", id);
        return ResponseEntity.ok(servicioService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<ServicioResponseDTO> crear(@Valid @RequestBody ServicioRequestDTO request) {
        log.info("Solicitud POST /api/v1/servicios");
        ServicioResponseDTO respuesta = servicioService.crear(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(respuesta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ServicioResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody ServicioRequestDTO request
    ) {
        log.info("Solicitud PUT /api/v1/servicios/{}", id);
        return ResponseEntity.ok(servicioService.actualizar(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("Solicitud DELETE /api/v1/servicios/{}", id);
        servicioService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}