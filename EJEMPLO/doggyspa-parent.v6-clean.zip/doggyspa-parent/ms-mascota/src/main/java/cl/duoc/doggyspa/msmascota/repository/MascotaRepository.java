package cl.duoc.doggyspa.msmascota.repository;

import cl.duoc.doggyspa.msmascota.model.Mascota;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MascotaRepository extends JpaRepository<Mascota, Long> {

    List<Mascota> findByIdCliente(Long idCliente);
}