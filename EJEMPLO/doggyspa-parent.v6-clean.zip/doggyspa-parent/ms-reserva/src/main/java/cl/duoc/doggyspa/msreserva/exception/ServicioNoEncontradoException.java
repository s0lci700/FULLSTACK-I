package cl.duoc.doggyspa.msreserva.exception;

public class ServicioNoEncontradoException extends RuntimeException {

    public ServicioNoEncontradoException(Long id) {
        super("No se encontró el servicio con ID: " + id);
    }
}