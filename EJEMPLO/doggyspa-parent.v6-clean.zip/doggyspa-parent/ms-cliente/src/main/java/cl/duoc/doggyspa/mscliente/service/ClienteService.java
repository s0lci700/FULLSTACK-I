package cl.duoc.doggyspa.mscliente.service;

import cl.duoc.doggyspa.mscliente.dto.ClienteRequestDTO;
import cl.duoc.doggyspa.mscliente.dto.ClienteResponseDTO;
import cl.duoc.doggyspa.mscliente.exception.ClienteNoEncontradoException;
import cl.duoc.doggyspa.mscliente.exception.CorreoDuplicadoException;
import cl.duoc.doggyspa.mscliente.model.Cliente;
import cl.duoc.doggyspa.mscliente.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public List<ClienteResponseDTO> listar() {
        log.info("Listando todos los clientes");

        return clienteRepository.findAll()
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public ClienteResponseDTO buscarPorId(Long id) {
        log.info("Buscando cliente con ID: {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Cliente no encontrado con ID: {}", id);
                    return new ClienteNoEncontradoException(id);
                });

        return mapearAResponse(cliente);
    }

    public ClienteResponseDTO crear(ClienteRequestDTO request) {
        log.info("Creando cliente con correo: {}", request.getCorreo());

        if (clienteRepository.existsByCorreo(request.getCorreo())) {
            log.warn("Intento de registrar correo duplicado: {}", request.getCorreo());
            throw new CorreoDuplicadoException(request.getCorreo());
        }

        Cliente cliente = Cliente.builder()
                .nombre(request.getNombre())
                .telefono(request.getTelefono())
                .correo(request.getCorreo())
                .direccion(request.getDireccion())
                .build();

        Cliente clienteGuardado = clienteRepository.save(cliente);

        log.info("Cliente creado correctamente con ID: {}", clienteGuardado.getIdCliente());

        return mapearAResponse(clienteGuardado);
    }

    public ClienteResponseDTO actualizar(Long id, ClienteRequestDTO request) {
        log.info("Actualizando cliente con ID: {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede actualizar. Cliente no encontrado con ID: {}", id);
                    return new ClienteNoEncontradoException(id);
                });

        clienteRepository.findByCorreo(request.getCorreo())
                .ifPresent(clienteExistente -> {
                    if (!clienteExistente.getIdCliente().equals(id)) {
                        log.warn("Correo duplicado al actualizar: {}", request.getCorreo());
                        throw new CorreoDuplicadoException(request.getCorreo());
                    }
                });

        cliente.setNombre(request.getNombre());
        cliente.setTelefono(request.getTelefono());
        cliente.setCorreo(request.getCorreo());
        cliente.setDireccion(request.getDireccion());

        Cliente clienteActualizado = clienteRepository.save(cliente);

        log.info("Cliente actualizado correctamente con ID: {}", clienteActualizado.getIdCliente());

        return mapearAResponse(clienteActualizado);
    }

    public void eliminar(Long id) {
        log.info("Eliminando cliente con ID: {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede eliminar. Cliente no encontrado con ID: {}", id);
                    return new ClienteNoEncontradoException(id);
                });

        clienteRepository.delete(cliente);

        log.info("Cliente eliminado correctamente con ID: {}", id);
    }

    private ClienteResponseDTO mapearAResponse(Cliente cliente) {
        return ClienteResponseDTO.builder()
                .idCliente(cliente.getIdCliente())
                .nombre(cliente.getNombre())
                .telefono(cliente.getTelefono())
                .correo(cliente.getCorreo())
                .direccion(cliente.getDireccion())
                .build();
    }
}