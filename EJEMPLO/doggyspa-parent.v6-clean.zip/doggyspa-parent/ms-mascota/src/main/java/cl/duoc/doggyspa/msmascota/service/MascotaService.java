package cl.duoc.doggyspa.msmascota.service;

import cl.duoc.doggyspa.msmascota.client.ClienteClient;
import cl.duoc.doggyspa.msmascota.dto.ClienteDTO;
import cl.duoc.doggyspa.msmascota.dto.MascotaRequestDTO;
import cl.duoc.doggyspa.msmascota.dto.MascotaResponseDTO;
import cl.duoc.doggyspa.msmascota.exception.ClienteNoEncontradoException;
import cl.duoc.doggyspa.msmascota.exception.MascotaNoEncontradaException;
import cl.duoc.doggyspa.msmascota.model.Mascota;
import cl.duoc.doggyspa.msmascota.repository.MascotaRepository;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class MascotaService {

    private final MascotaRepository mascotaRepository;
    private final ClienteClient clienteClient;

    public List<MascotaResponseDTO> listar() {
        log.info("Listando todas las mascotas");

        return mascotaRepository.findAll()
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public MascotaResponseDTO buscarPorId(Long id) {
        log.info("Buscando mascota con ID: {}", id);

        Mascota mascota = mascotaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Mascota no encontrada con ID: {}", id);
                    return new MascotaNoEncontradaException(id);
                });

        return mapearAResponse(mascota);
    }

    public List<MascotaResponseDTO> listarPorCliente(Long idCliente) {
        log.info("Listando mascotas del cliente con ID: {}", idCliente);

        validarClienteExiste(idCliente);

        return mascotaRepository.findByIdCliente(idCliente)
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public MascotaResponseDTO crear(MascotaRequestDTO request) {
        log.info("Creando mascota para cliente ID: {}", request.getIdCliente());

        validarClienteExiste(request.getIdCliente());

        Mascota mascota = Mascota.builder()
                .nombre(request.getNombre())
                .raza(request.getRaza())
                .edad(request.getEdad())
                .peso(request.getPeso())
                .observacion(request.getObservacion())
                .idCliente(request.getIdCliente())
                .build();

        Mascota mascotaGuardada = mascotaRepository.save(mascota);

        log.info("Mascota creada correctamente con ID: {}", mascotaGuardada.getIdMascota());

        return mapearAResponse(mascotaGuardada);
    }

    public MascotaResponseDTO actualizar(Long id, MascotaRequestDTO request) {
        log.info("Actualizando mascota con ID: {}", id);

        validarClienteExiste(request.getIdCliente());

        Mascota mascota = mascotaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede actualizar. Mascota no encontrada con ID: {}", id);
                    return new MascotaNoEncontradaException(id);
                });

        mascota.setNombre(request.getNombre());
        mascota.setRaza(request.getRaza());
        mascota.setEdad(request.getEdad());
        mascota.setPeso(request.getPeso());
        mascota.setObservacion(request.getObservacion());
        mascota.setIdCliente(request.getIdCliente());

        Mascota mascotaActualizada = mascotaRepository.save(mascota);

        log.info("Mascota actualizada correctamente con ID: {}", mascotaActualizada.getIdMascota());

        return mapearAResponse(mascotaActualizada);
    }

    public void eliminar(Long id) {
        log.info("Eliminando mascota con ID: {}", id);

        Mascota mascota = mascotaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede eliminar. Mascota no encontrada con ID: {}", id);
                    return new MascotaNoEncontradaException(id);
                });

        mascotaRepository.delete(mascota);

        log.info("Mascota eliminada correctamente con ID: {}", id);
    }

    private void validarClienteExiste(Long idCliente) {
        try {
            log.info("Validando existencia del cliente ID: {}", idCliente);

            ClienteDTO cliente = clienteClient.buscarClientePorId(idCliente);

            if (cliente == null || cliente.getIdCliente() == null) {
                log.warn("Cliente no encontrado con ID: {}", idCliente);
                throw new ClienteNoEncontradoException(idCliente);
            }

            log.info("Cliente validado correctamente: {} - {}", cliente.getIdCliente(), cliente.getNombre());

        } catch (FeignException.NotFound ex) {
            log.warn("Cliente no encontrado en ms-cliente. ID: {}", idCliente);
            throw new ClienteNoEncontradoException(idCliente);

        } catch (FeignException ex) {
            log.error("Error al comunicarse con ms-cliente. Estado: {}, mensaje: {}", ex.status(), ex.getMessage());
            throw new RuntimeException("No fue posible validar el cliente en este momento");
        }
    }

    private MascotaResponseDTO mapearAResponse(Mascota mascota) {
        return MascotaResponseDTO.builder()
                .idMascota(mascota.getIdMascota())
                .nombre(mascota.getNombre())
                .raza(mascota.getRaza())
                .edad(mascota.getEdad())
                .peso(mascota.getPeso())
                .observacion(mascota.getObservacion())
                .idCliente(mascota.getIdCliente())
                .build();
    }
}