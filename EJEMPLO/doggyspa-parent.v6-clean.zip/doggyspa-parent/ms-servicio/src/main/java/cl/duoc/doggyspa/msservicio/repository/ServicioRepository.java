package cl.duoc.doggyspa.msservicio.repository;

import cl.duoc.doggyspa.msservicio.model.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ServicioRepository extends JpaRepository<Servicio, Long> {

    List<Servicio> findByActivoTrue();

    List<Servicio> findByNombreContainingIgnoreCase(String nombre);
}