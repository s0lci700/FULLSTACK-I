package cl.duoc.doggyspa.msreserva.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
public class ReservaResponseDTO {

    private Long idReserva;
    private LocalDate fecha;
    private LocalTime hora;
    private String estado;
    private String observacion;
    private Long idMascota;
    private Long idServicio;

    private String nombreMascota;
    private String nombreServicio;
    private String precioServicio;
}