package cl.duoc.doggyspa.msreserva.repository;

import cl.duoc.doggyspa.msreserva.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    List<Reserva> findByIdMascota(Long idMascota);

    List<Reserva> findByFecha(LocalDate fecha);

    List<Reserva> findByEstadoIgnoreCase(String estado);
}