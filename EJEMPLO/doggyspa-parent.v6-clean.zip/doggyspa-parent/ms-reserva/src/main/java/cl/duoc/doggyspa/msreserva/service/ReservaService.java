package cl.duoc.doggyspa.msreserva.service;

import cl.duoc.doggyspa.msreserva.client.MascotaClient;
import cl.duoc.doggyspa.msreserva.client.ServicioClient;
import cl.duoc.doggyspa.msreserva.dto.MascotaDTO;
import cl.duoc.doggyspa.msreserva.dto.ReservaRequestDTO;
import cl.duoc.doggyspa.msreserva.dto.ReservaResponseDTO;
import cl.duoc.doggyspa.msreserva.dto.ServicioDTO;
import cl.duoc.doggyspa.msreserva.exception.MascotaNoEncontradaException;
import cl.duoc.doggyspa.msreserva.exception.ReservaNoEncontradaException;
import cl.duoc.doggyspa.msreserva.exception.ServicioInactivoException;
import cl.duoc.doggyspa.msreserva.exception.ServicioNoEncontradoException;
import cl.duoc.doggyspa.msreserva.model.Reserva;
import cl.duoc.doggyspa.msreserva.repository.ReservaRepository;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final MascotaClient mascotaClient;
    private final ServicioClient servicioClient;

    public List<ReservaResponseDTO> listar() {
        log.info("Listando todas las reservas");

        return reservaRepository.findAll()
                .stream()
                .map(this::mapearAResponseConDatosExternos)
                .toList();
    }

    public ReservaResponseDTO buscarPorId(Long id) {
        log.info("Buscando reserva con ID: {}", id);

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Reserva no encontrada con ID: {}", id);
                    return new ReservaNoEncontradaException(id);
                });

        return mapearAResponseConDatosExternos(reserva);
    }

    public List<ReservaResponseDTO> listarPorMascota(Long idMascota) {
        log.info("Listando reservas de mascota ID: {}", idMascota);

        validarMascotaExiste(idMascota);

        return reservaRepository.findByIdMascota(idMascota)
                .stream()
                .map(this::mapearAResponseConDatosExternos)
                .toList();
    }

    public List<ReservaResponseDTO> listarPorEstado(String estado) {
        log.info("Listando reservas por estado: {}", estado);

        return reservaRepository.findByEstadoIgnoreCase(estado)
                .stream()
                .map(this::mapearAResponseConDatosExternos)
                .toList();
    }

    public ReservaResponseDTO crear(ReservaRequestDTO request) {
        log.info("Creando reserva para mascota ID: {} y servicio ID: {}",
                request.getIdMascota(),
                request.getIdServicio());

        MascotaDTO mascota = validarMascotaExiste(request.getIdMascota());
        ServicioDTO servicio = validarServicioExisteYActivo(request.getIdServicio());

        Reserva reserva = Reserva.builder()
                .fecha(request.getFecha())
                .hora(request.getHora())
                .estado("AGENDADA")
                .observacion(request.getObservacion())
                .idMascota(request.getIdMascota())
                .idServicio(request.getIdServicio())
                .build();

        Reserva reservaGuardada = reservaRepository.save(reserva);

        log.info("Reserva creada correctamente con ID: {}", reservaGuardada.getIdReserva());

        return mapearAResponse(reservaGuardada, mascota, servicio);
    }

    public ReservaResponseDTO actualizar(Long id, ReservaRequestDTO request) {
        log.info("Actualizando reserva con ID: {}", id);

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede actualizar. Reserva no encontrada con ID: {}", id);
                    return new ReservaNoEncontradaException(id);
                });

        MascotaDTO mascota = validarMascotaExiste(request.getIdMascota());
        ServicioDTO servicio = validarServicioExisteYActivo(request.getIdServicio());

        reserva.setFecha(request.getFecha());
        reserva.setHora(request.getHora());
        reserva.setObservacion(request.getObservacion());
        reserva.setIdMascota(request.getIdMascota());
        reserva.setIdServicio(request.getIdServicio());

        Reserva reservaActualizada = reservaRepository.save(reserva);

        log.info("Reserva actualizada correctamente con ID: {}", reservaActualizada.getIdReserva());

        return mapearAResponse(reservaActualizada, mascota, servicio);
    }

    public ReservaResponseDTO cambiarEstado(Long id, String estado) {
        log.info("Cambiando estado de reserva ID: {} a {}", id, estado);

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede cambiar estado. Reserva no encontrada con ID: {}", id);
                    return new ReservaNoEncontradaException(id);
                });

        reserva.setEstado(estado.toUpperCase());

        Reserva reservaActualizada = reservaRepository.save(reserva);

        return mapearAResponseConDatosExternos(reservaActualizada);
    }

    public void eliminar(Long id) {
        log.info("Eliminando reserva con ID: {}", id);

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede eliminar. Reserva no encontrada con ID: {}", id);
                    return new ReservaNoEncontradaException(id);
                });

        reservaRepository.delete(reserva);

        log.info("Reserva eliminada correctamente con ID: {}", id);
    }

    private MascotaDTO validarMascotaExiste(Long idMascota) {
        try {
            log.info("Validando existencia de mascota ID: {}", idMascota);

            MascotaDTO mascota = mascotaClient.buscarMascotaPorId(idMascota);

            if (mascota == null || mascota.getIdMascota() == null) {
                throw new MascotaNoEncontradaException(idMascota);
            }

            log.info("Mascota validada correctamente: {}", mascota.getNombre());

            return mascota;

        } catch (FeignException.NotFound ex) {
            log.warn("Mascota no encontrada en ms-mascota. ID: {}", idMascota);
            throw new MascotaNoEncontradaException(idMascota);

        } catch (FeignException ex) {
            log.error("Error al comunicarse con ms-mascota. Estado: {}", ex.status());
            throw new RuntimeException("No fue posible validar la mascota en este momento");
        }
    }

    private ServicioDTO validarServicioExisteYActivo(Long idServicio) {
        try {
            log.info("Validando existencia de servicio ID: {}", idServicio);

            ServicioDTO servicio = servicioClient.buscarServicioPorId(idServicio);

            if (servicio == null || servicio.getIdServicio() == null) {
                throw new ServicioNoEncontradoException(idServicio);
            }

            if (Boolean.FALSE.equals(servicio.getActivo())) {
                log.warn("Servicio inactivo con ID: {}", idServicio);
                throw new ServicioInactivoException(idServicio);
            }

            log.info("Servicio validado correctamente: {}", servicio.getNombre());

            return servicio;

        } catch (FeignException.NotFound ex) {
            log.warn("Servicio no encontrado en ms-servicio. ID: {}", idServicio);
            throw new ServicioNoEncontradoException(idServicio);

        } catch (FeignException ex) {
            log.error("Error al comunicarse con ms-servicio. Estado: {}", ex.status());
            throw new RuntimeException("No fue posible validar el servicio en este momento");
        }
    }

    private ReservaResponseDTO mapearAResponseConDatosExternos(Reserva reserva) {
        MascotaDTO mascota = validarMascotaExiste(reserva.getIdMascota());
        ServicioDTO servicio = validarServicioExisteYActivo(reserva.getIdServicio());

        return mapearAResponse(reserva, mascota, servicio);
    }

    private ReservaResponseDTO mapearAResponse(
            Reserva reserva,
            MascotaDTO mascota,
            ServicioDTO servicio
    ) {
        return ReservaResponseDTO.builder()
                .idReserva(reserva.getIdReserva())
                .fecha(reserva.getFecha())
                .hora(reserva.getHora())
                .estado(reserva.getEstado())
                .observacion(reserva.getObservacion())
                .idMascota(reserva.getIdMascota())
                .idServicio(reserva.getIdServicio())
                .nombreMascota(mascota.getNombre())
                .nombreServicio(servicio.getNombre())
                .precioServicio(servicio.getPrecio() != null ? servicio.getPrecio().toString() : null)
                .build();
    }
}