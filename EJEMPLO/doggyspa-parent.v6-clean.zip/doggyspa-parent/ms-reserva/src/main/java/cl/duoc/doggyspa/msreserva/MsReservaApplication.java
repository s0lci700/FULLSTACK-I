package cl.duoc.doggyspa.msreserva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class MsReservaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsReservaApplication.class, args);
    }

}