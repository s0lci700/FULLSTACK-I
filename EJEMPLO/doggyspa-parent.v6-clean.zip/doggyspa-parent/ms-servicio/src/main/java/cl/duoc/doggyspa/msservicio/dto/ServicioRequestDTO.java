package cl.duoc.doggyspa.msservicio.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ServicioRequestDTO {

    @NotBlank(message = "El nombre del servicio es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    private String nombre;

    @NotBlank(message = "La descripción es obligatoria")
    @Size(max = 255, message = "La descripción no puede superar los 255 caracteres")
    private String descripcion;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "1000.0", message = "El precio debe ser igual o superior a 1000")
    private BigDecimal precio;

    @NotNull(message = "La duración es obligatoria")
    @Min(value = 5, message = "La duración mínima es de 5 minutos")
    @Max(value = 240, message = "La duración máxima es de 240 minutos")
    private Integer duracionMinutos;

    @NotNull(message = "El estado activo es obligatorio")
    private Boolean activo;
}