package cl.duoc.doggyspa.mspago.client;

import cl.duoc.doggyspa.mspago.dto.ReservaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ms-reserva")
public interface ReservaClient {

    @GetMapping("/api/v1/reservas/{id}")
    ReservaDTO buscarReservaPorId(@PathVariable("id") Long id);
}