package cl.duoc.doggyspa.msmascota.client;

import cl.duoc.doggyspa.msmascota.dto.ClienteDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ms-cliente")
public interface ClienteClient {

    @GetMapping("/api/v1/clientes/{id}")
    ClienteDTO buscarClientePorId(@PathVariable("id") Long id);
}