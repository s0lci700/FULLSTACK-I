package cl.duoc.doggyspa.msmascota.dto;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class MascotaResponseDTO {

    private Long idMascota;
    private String nombre;
    private String raza;
    private Integer edad;
    private BigDecimal peso;
    private String observacion;
    private Long idCliente;
}