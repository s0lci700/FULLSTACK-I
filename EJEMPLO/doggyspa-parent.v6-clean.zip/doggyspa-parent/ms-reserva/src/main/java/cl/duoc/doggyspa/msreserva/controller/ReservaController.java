package cl.duoc.doggyspa.msreserva.controller;

import cl.duoc.doggyspa.msreserva.dto.ReservaRequestDTO;
import cl.duoc.doggyspa.msreserva.dto.ReservaResponseDTO;
import cl.duoc.doggyspa.msreserva.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/reservas")
@RequiredArgsConstructor
public class ReservaController {

    private final ReservaService reservaService;

    @GetMapping
    public ResponseEntity<?> listar() {
        log.info("Solicitud GET /api/v1/reservas");
        return ResponseEntity.ok(reservaService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDTO> buscarPorId(@PathVariable Long id) {
        log.info("Solicitud GET /api/v1/reservas/{}", id);
        return ResponseEntity.ok(reservaService.buscarPorId(id));
    }

    @GetMapping("/mascota/{idMascota}")
    public ResponseEntity<?> listarPorMascota(@PathVariable Long idMascota) {
        log.info("Solicitud GET /api/v1/reservas/mascota/{}", idMascota);
        return ResponseEntity.ok(reservaService.listarPorMascota(idMascota));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<?> listarPorEstado(@PathVariable String estado) {
        log.info("Solicitud GET /api/v1/reservas/estado/{}", estado);
        return ResponseEntity.ok(reservaService.listarPorEstado(estado));
    }

    @PostMapping
    public ResponseEntity<ReservaResponseDTO> crear(@Valid @RequestBody ReservaRequestDTO request) {
        log.info("Solicitud POST /api/v1/reservas");
        ReservaResponseDTO respuesta = reservaService.crear(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(respuesta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReservaResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody ReservaRequestDTO request
    ) {
        log.info("Solicitud PUT /api/v1/reservas/{}", id);
        return ResponseEntity.ok(reservaService.actualizar(id, request));
    }

    @PatchMapping("/{id}/estado")
    public ResponseEntity<ReservaResponseDTO> cambiarEstado(
            @PathVariable Long id,
            @RequestParam String estado
    ) {
        log.info("Solicitud PATCH /api/v1/reservas/{}/estado?estado={}", id, estado);
        return ResponseEntity.ok(reservaService.cambiarEstado(id, estado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("Solicitud DELETE /api/v1/reservas/{}", id);
        reservaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}