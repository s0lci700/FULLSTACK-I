package cl.duoc.doggyspa.msreserva.client;

import cl.duoc.doggyspa.msreserva.dto.MascotaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ms-mascota")
public interface MascotaClient {

    @GetMapping("/api/v1/mascotas/{id}")
    MascotaDTO buscarMascotaPorId(@PathVariable("id") Long id);
}