package cl.duoc.doggyspa.msmascota.controller;

import cl.duoc.doggyspa.msmascota.dto.MascotaRequestDTO;
import cl.duoc.doggyspa.msmascota.dto.MascotaResponseDTO;
import cl.duoc.doggyspa.msmascota.service.MascotaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/mascotas")
@RequiredArgsConstructor
public class MascotaController {

    private final MascotaService mascotaService;

    @GetMapping
    public ResponseEntity<?> listar() {
        log.info("Solicitud GET /api/v1/mascotas");
        return ResponseEntity.ok(mascotaService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MascotaResponseDTO> buscarPorId(@PathVariable Long id) {
        log.info("Solicitud GET /api/v1/mascotas/{}", id);
        return ResponseEntity.ok(mascotaService.buscarPorId(id));
    }

    @GetMapping("/cliente/{idCliente}")
    public ResponseEntity<?> listarPorCliente(@PathVariable Long idCliente) {
        log.info("Solicitud GET /api/v1/mascotas/cliente/{}", idCliente);
        return ResponseEntity.ok(mascotaService.listarPorCliente(idCliente));
    }

    @PostMapping
    public ResponseEntity<MascotaResponseDTO> crear(@Valid @RequestBody MascotaRequestDTO request) {
        log.info("Solicitud POST /api/v1/mascotas");
        MascotaResponseDTO respuesta = mascotaService.crear(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(respuesta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MascotaResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody MascotaRequestDTO request
    ) {
        log.info("Solicitud PUT /api/v1/mascotas/{}", id);
        return ResponseEntity.ok(mascotaService.actualizar(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("Solicitud DELETE /api/v1/mascotas/{}", id);
        mascotaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}