package cl.duoc.doggyspa.mspago.repository;

import cl.duoc.doggyspa.mspago.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PagoRepository extends JpaRepository<Pago, Long> {

    List<Pago> findByIdReserva(Long idReserva);

    List<Pago> findByEstadoIgnoreCase(String estado);

    List<Pago> findByMetodoIgnoreCase(String metodo);
}