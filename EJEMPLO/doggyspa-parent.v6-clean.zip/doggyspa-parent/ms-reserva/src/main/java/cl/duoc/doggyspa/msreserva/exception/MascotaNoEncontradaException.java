package cl.duoc.doggyspa.msreserva.exception;

public class MascotaNoEncontradaException extends RuntimeException {

    public MascotaNoEncontradaException(Long id) {
        super("No se encontró la mascota con ID: " + id);
    }
}