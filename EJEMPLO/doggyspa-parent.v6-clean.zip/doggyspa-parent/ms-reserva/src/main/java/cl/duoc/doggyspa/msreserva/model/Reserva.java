package cl.duoc.doggyspa.msreserva.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "reserva")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva")
    private Long idReserva;

    @NotNull(message = "La fecha de la reserva es obligatoria")
    @Column(nullable = false)
    private LocalDate fecha;

    @NotNull(message = "La hora de la reserva es obligatoria")
    @Column(nullable = false)
    private LocalTime hora;

    @Size(max = 30, message = "El estado no puede superar los 30 caracteres")
    @Column(nullable = false, length = 30)
    private String estado;

    @Size(max = 255, message = "La observación no puede superar los 255 caracteres")
    @Column(length = 255)
    private String observacion;

    @NotNull(message = "El ID de la mascota es obligatorio")
    @Column(name = "id_mascota", nullable = false)
    private Long idMascota;

    @NotNull(message = "El ID del servicio es obligatorio")
    @Column(name = "id_servicio", nullable = false)
    private Long idServicio;
}