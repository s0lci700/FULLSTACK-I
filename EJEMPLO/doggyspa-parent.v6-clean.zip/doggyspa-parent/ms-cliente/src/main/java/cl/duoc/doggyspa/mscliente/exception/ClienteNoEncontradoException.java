package cl.duoc.doggyspa.mscliente.exception;

public class ClienteNoEncontradoException extends RuntimeException {

    public ClienteNoEncontradoException(Long id) {
        super("No se encontró el cliente con ID: " + id);
    }
}