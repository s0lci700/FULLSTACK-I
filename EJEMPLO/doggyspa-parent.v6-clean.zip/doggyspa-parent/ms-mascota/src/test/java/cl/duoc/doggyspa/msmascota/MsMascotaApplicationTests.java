package cl.duoc.doggyspa.msmascota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMascotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
