package cl.duoc.doggyspa.mspago.exception;

public class PagoNoEncontradoException extends RuntimeException {

    public PagoNoEncontradoException(Long id) {
        super("No se encontró el pago con ID: " + id);
    }
}