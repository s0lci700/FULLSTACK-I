package cl.duoc.doggyspa.frontendweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
