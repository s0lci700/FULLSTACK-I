package cl.duoc.doggyspa.msreserva.client;

import cl.duoc.doggyspa.msreserva.dto.ServicioDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ms-servicio")
public interface ServicioClient {

    @GetMapping("/api/v1/servicios/{id}")
    ServicioDTO buscarServicioPorId(@PathVariable("id") Long id);
}