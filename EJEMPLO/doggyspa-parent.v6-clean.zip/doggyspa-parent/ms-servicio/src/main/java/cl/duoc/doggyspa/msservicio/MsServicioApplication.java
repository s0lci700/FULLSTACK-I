package cl.duoc.doggyspa.msservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsServicioApplication.class, args);
	}

}
