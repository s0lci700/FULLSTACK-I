package cl.duoc.doggyspa.msreserva.exception;

public class ServicioInactivoException extends RuntimeException {

    public ServicioInactivoException(Long id) {
        super("El servicio con ID " + id + " se encuentra inactivo y no puede ser reservado");
    }
}