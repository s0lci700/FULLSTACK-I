package cl.duoc.doggyspa.msservicio.service;

import cl.duoc.doggyspa.msservicio.dto.ServicioRequestDTO;
import cl.duoc.doggyspa.msservicio.dto.ServicioResponseDTO;
import cl.duoc.doggyspa.msservicio.exception.ServicioNoEncontradoException;
import cl.duoc.doggyspa.msservicio.model.Servicio;
import cl.duoc.doggyspa.msservicio.repository.ServicioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServicioService {

    private final ServicioRepository servicioRepository;

    public List<ServicioResponseDTO> listar() {
        log.info("Listando todos los servicios");

        return servicioRepository.findAll()
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public List<ServicioResponseDTO> listarActivos() {
        log.info("Listando servicios activos");

        return servicioRepository.findByActivoTrue()
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public List<ServicioResponseDTO> buscarPorNombre(String nombre) {
        log.info("Buscando servicios por nombre: {}", nombre);

        return servicioRepository.findByNombreContainingIgnoreCase(nombre)
                .stream()
                .map(this::mapearAResponse)
                .toList();
    }

    public ServicioResponseDTO buscarPorId(Long id) {
        log.info("Buscando servicio con ID: {}", id);

        Servicio servicio = servicioRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Servicio no encontrado con ID: {}", id);
                    return new ServicioNoEncontradoException(id);
                });

        return mapearAResponse(servicio);
    }

    public ServicioResponseDTO crear(ServicioRequestDTO request) {
        log.info("Creando servicio: {}", request.getNombre());

        Servicio servicio = Servicio.builder()
                .nombre(request.getNombre())
                .descripcion(request.getDescripcion())
                .precio(request.getPrecio())
                .duracionMinutos(request.getDuracionMinutos())
                .activo(request.getActivo())
                .build();

        Servicio servicioGuardado = servicioRepository.save(servicio);

        log.info("Servicio creado correctamente con ID: {}", servicioGuardado.getIdServicio());

        return mapearAResponse(servicioGuardado);
    }

    public ServicioResponseDTO actualizar(Long id, ServicioRequestDTO request) {
        log.info("Actualizando servicio con ID: {}", id);

        Servicio servicio = servicioRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede actualizar. Servicio no encontrado con ID: {}", id);
                    return new ServicioNoEncontradoException(id);
                });

        servicio.setNombre(request.getNombre());
        servicio.setDescripcion(request.getDescripcion());
        servicio.setPrecio(request.getPrecio());
        servicio.setDuracionMinutos(request.getDuracionMinutos());
        servicio.setActivo(request.getActivo());

        Servicio servicioActualizado = servicioRepository.save(servicio);

        log.info("Servicio actualizado correctamente con ID: {}", servicioActualizado.getIdServicio());

        return mapearAResponse(servicioActualizado);
    }

    public void eliminar(Long id) {
        log.info("Eliminando servicio con ID: {}", id);

        Servicio servicio = servicioRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se puede eliminar. Servicio no encontrado con ID: {}", id);
                    return new ServicioNoEncontradoException(id);
                });

        servicioRepository.delete(servicio);

        log.info("Servicio eliminado correctamente con ID: {}", id);
    }

    private ServicioResponseDTO mapearAResponse(Servicio servicio) {
        return ServicioResponseDTO.builder()
                .idServicio(servicio.getIdServicio())
                .nombre(servicio.getNombre())
                .descripcion(servicio.getDescripcion())
                .precio(servicio.getPrecio())
                .duracionMinutos(servicio.getDuracionMinutos())
                .activo(servicio.getActivo())
                .build();
    }
}