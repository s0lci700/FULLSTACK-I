package cl.duoc.doggyspa.msmascota.exception;

public class ClienteNoEncontradoException extends RuntimeException {

    public ClienteNoEncontradoException(Long idCliente) {
        super("No se encontró el cliente con ID: " + idCliente);
    }
}