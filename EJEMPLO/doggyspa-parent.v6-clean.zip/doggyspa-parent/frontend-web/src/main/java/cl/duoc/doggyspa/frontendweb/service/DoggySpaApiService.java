package cl.duoc.doggyspa.frontendweb.service;

import cl.duoc.doggyspa.frontendweb.dto.ClienteDTO;
import cl.duoc.doggyspa.frontendweb.dto.MascotaDTO;
import cl.duoc.doggyspa.frontendweb.dto.PagoDTO;
import cl.duoc.doggyspa.frontendweb.dto.ReservaDTO;
import cl.duoc.doggyspa.frontendweb.dto.ServicioDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DoggySpaApiService {

    private final RestTemplate restTemplate;

    @Value("${doggyspa.api-gateway.url}")
    private String apiGatewayUrl;

    public List<ClienteDTO> listarClientes() {
        try {
            ClienteDTO[] respuesta = restTemplate.getForObject(
                    apiGatewayUrl + "/api/v1/clientes",
                    ClienteDTO[].class
            );

            return respuesta != null ? Arrays.asList(respuesta) : Collections.emptyList();

        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public List<MascotaDTO> listarMascotas() {
        try {
            MascotaDTO[] respuesta = restTemplate.getForObject(
                    apiGatewayUrl + "/api/v1/mascotas",
                    MascotaDTO[].class
            );

            return respuesta != null ? Arrays.asList(respuesta) : Collections.emptyList();

        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public List<ServicioDTO> listarServicios() {
        try {
            ServicioDTO[] respuesta = restTemplate.getForObject(
                    apiGatewayUrl + "/api/v1/servicios",
                    ServicioDTO[].class
            );

            return respuesta != null ? Arrays.asList(respuesta) : Collections.emptyList();

        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public List<ReservaDTO> listarReservas() {
        try {
            ReservaDTO[] respuesta = restTemplate.getForObject(
                    apiGatewayUrl + "/api/v1/reservas",
                    ReservaDTO[].class
            );

            return respuesta != null ? Arrays.asList(respuesta) : Collections.emptyList();

        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public List<PagoDTO> listarPagos() {
        try {
            PagoDTO[] respuesta = restTemplate.getForObject(
                    apiGatewayUrl + "/api/v1/pagos",
                    PagoDTO[].class
            );

            return respuesta != null ? Arrays.asList(respuesta) : Collections.emptyList();

        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}