package cl.duoc.doggyspa.frontendweb.dto;

import lombok.Data;

@Data
public class ClienteDTO {

    private Long idCliente;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;
}