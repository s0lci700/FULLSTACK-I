package cl.duoc.doggyspa.msservicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
