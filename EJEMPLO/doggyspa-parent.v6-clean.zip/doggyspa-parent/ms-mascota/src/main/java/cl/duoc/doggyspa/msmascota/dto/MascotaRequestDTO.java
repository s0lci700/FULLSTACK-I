package cl.duoc.doggyspa.msmascota.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class MascotaRequestDTO {

    @NotBlank(message = "El nombre de la mascota es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    private String nombre;

    @NotBlank(message = "La raza es obligatoria")
    @Size(max = 80, message = "La raza no puede superar los 80 caracteres")
    private String raza;

    @NotNull(message = "La edad es obligatoria")
    @Min(value = 0, message = "La edad no puede ser negativa")
    @Max(value = 30, message = "La edad no puede superar los 30 años")
    private Integer edad;

    @NotNull(message = "El peso es obligatorio")
    @DecimalMin(value = "0.1", message = "El peso debe ser mayor a 0")
    @DecimalMax(value = "100.0", message = "El peso no puede superar los 100 kg")
    private BigDecimal peso;

    @Size(max = 255, message = "La observación no puede superar los 255 caracteres")
    private String observacion;

    @NotNull(message = "El ID del cliente es obligatorio")
    private Long idCliente;
}