package cl.duoc.doggyspa.mscliente.controller;

import cl.duoc.doggyspa.mscliente.dto.ClienteRequestDTO;
import cl.duoc.doggyspa.mscliente.dto.ClienteResponseDTO;
import cl.duoc.doggyspa.mscliente.service.ClienteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/clientes")
@RequiredArgsConstructor
public class ClienteController {

    private final ClienteService clienteService;

    @GetMapping
    public ResponseEntity<?> listar() {
        log.info("Solicitud GET /api/v1/clientes");
        return ResponseEntity.ok(clienteService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteResponseDTO> buscarPorId(@PathVariable Long id) {
        log.info("Solicitud GET /api/v1/clientes/{}", id);
        return ResponseEntity.ok(clienteService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<ClienteResponseDTO> crear(@Valid @RequestBody ClienteRequestDTO request) {
        log.info("Solicitud POST /api/v1/clientes");
        ClienteResponseDTO respuesta = clienteService.crear(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(respuesta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClienteResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody ClienteRequestDTO request
    ) {
        log.info("Solicitud PUT /api/v1/clientes/{}", id);
        return ResponseEntity.ok(clienteService.actualizar(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("Solicitud DELETE /api/v1/clientes/{}", id);
        clienteService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}