package cl.duoc.doggyspa.mscliente.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ClienteResponseDTO {

    private Long idCliente;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;
}